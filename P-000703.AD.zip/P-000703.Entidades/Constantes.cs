﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_000703.Entidades
{
    public class Constantes
    {
        public const String COD_CORRECTO = "00";
        public const String COD_ADVERTENCIA = "98";
        public const String COD_ERROR = "99";
    }
}
